void ar_list(int ar_fd, int verbosity);
void ar_ext(int ar_fd, int argc, char **argv);
void ar_app(int ar_fd, int argc, char **argv);
void ar_appall(int ar_fd, int argc, char **argv);
void ar_del(int ar_fd, int argc, char **argv);
